import express from "express";
import bodyParser from "body-parser";
import pg from 'pg';

const app = express();
const port = process.env.PORT || 8080;

const db = new pg.Client({
  user: 'mhhoymjo_postgres',                
    host: 'localhost',                         
    database: 'mhhoymjo_to_do_app_backend',        
    password: process.env.DB_PASSWORD,  
    port: 5432,  
})
db.connect();

app.use(bodyParser.urlencoded({ extended: true }));

const basePath = '/to-do-app-backend';
app.use(basePath, express.static("public"));

let items = [
  { id: 1, title: "Buy milk" },
  { id: 2, title: "Finish homework" },
];

app.get(`${basePath}/`, async (req, res) => {
  try {
    const result = await db.query(
      // Mistake: didn't select the ID, so had got a problem retrieving the ID data from teh database!!!!
      // Also, ORDER BY id ASC helped selecting the corresponding ID in the right order (without ORDER BY, items got messed in the list like edited items got duplicated and added up to the bottom)
      // ORDER BY id ASC basically acts for pinning up the latest item edited.
      "SELECT * FROM items ORDER BY id ASC"
    );
    // Mistake: missed extracting rows from the database (result)
    const listItems = result.rows;

    res.render("index.ejs", {
      listTitle: "To-Do List",
      listItems: listItems,
      basePath
    });
  } catch (err) {
     console.error("Error fetching items:", err);
  }
});

app.post(`${basePath}/add`, (req, res) => {
  const item = req.body.newItem;
  console.log("User Input:", item);

  if (item) {
    db.query(
      "INSERT INTO items(title) VALUES($1)",
      [item]
    );
  };
  
  res.redirect(`${basePath}`);
});

app.post(`${basePath}/edit`, async (req, res) => {
  const item = req.body.updatedItemTitle;
  const id = req.body.updatedItemId;
 
  console.log("id:", id, "item:", item);

  try {
      await db.query(
        "UPDATE items SET title = $1 WHERE id = $2",
        [item, id]
      );
      res.redirect(`${basePath}`);
 
  } catch (err) {
    console.error("Error editing data:", err);
  } 
});

app.post(`${basePath}/delete`, async (req, res) => {
  const deleteItem = req.body.deleteItemId; 
  console.log(deleteItem);

  try {
    await db.query(
      "DELETE FROM items WHERE id = $1",
      [deleteItem]
    );
    res.redirect(`${basePath}`);
  } catch (err) {
    console.error(err);
  }
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
